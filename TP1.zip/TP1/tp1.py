import scipy.io.wavfile
import os
import canaux24
import numpy as np
import matplotlib.pyplot as plt



def lecture(voyelle, nb_fichiers):
    selection = []
    res = []
    liste_fichiers = os.listdir("Signal/")
    for NomFichier in liste_fichiers:
        try:
            if(int(NomFichier[2:4])<nb_fichiers and NomFichier[0:2] in voyelle):
                selection.append(NomFichier)
        except:
            pass

    for NomFichier in selection:
        (Fe,Echantillons)=scipy.io.wavfile.read("Signal/"+NomFichier)
        can = canaux24.canaux(signal=Echantillons,Fs=Fe)
        res.append(can)

    return np.array(res)
"""
obsaa = lecture('aa',100) 
obsee = lecture('ee',100) 
obseh = lecture('eh',100)
obseu = lecture('eu',100)
obsii = lecture('ii',100)
obsoe = lecture('oe',100)
obsoh = lecture('oh',100)
obsoo = lecture('oo',100)
obsuu = lecture('uu',100)
obsyy = lecture('yy',100)
"""
R=lecture("aa ee eh eu ii oe oh oo uu yy",100)
#R = np.concatenate((obsaa,obsee,obseh,obseu,obsii,obsoe,obsoh,obsoo,obsuu,obsyy))
covarianceR = np.cov(np.transpose(R))
(valeur, vecteur) = np.linalg.eig(covarianceR)
representation = np.dot(R,(np.transpose(vecteur[0:2])))
"""
plt.plot(np.transpose(representation[0:20])[1],np.transpose(representation[0:20])[0],"+")
plt.plot(np.transpose(representation[20:40])[1],np.transpose(representation[20:40])[0],"+")
plt.plot(np.transpose(representation[40:60])[1],np.transpose(representation[40:60])[0],"+")
"""
plt.plot(np.transpose(representation)[0],np.transpose(representation)[1],"+")
plt.show()
